package player;

import ch.aplu.jcardgame.Card;
import ch.aplu.jcardgame.Hand;

public interface IPlayer {

	public int getID();

	public int getScore();

	public void setInitHand(Hand handCards); // set the hand to the dealed card of the player

	public Hand getHand();

	public Card play();

	public void win(); // increase the score if winned

}
