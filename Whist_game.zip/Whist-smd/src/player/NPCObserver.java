package player;

import ch.aplu.jcardgame.Card;
import whist.Whist;

public interface NPCObserver {
	// interface to facilitates the implemented one to become the observer in Subject class.

	void update(Card card); // pass through a card to the listener

	void updateTrump(Whist.Suit trump);

	void clear(); // told the player it is end of a trick and do something

}
