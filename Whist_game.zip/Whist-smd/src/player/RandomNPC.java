package player;

import ch.aplu.jcardgame.Card;
import ch.aplu.jgamegrid.GameGrid;

public class RandomNPC extends NPCPlayer {

	// Inherits the NPCPlayer. Play method is to randomly choose any card in hand.

	public RandomNPC(int id) {
		super(id);
	}

	@Override
	public Card play() {
		selected = null;
		selected = randomCard(hand);
		GameGrid.delay(thinkingTime);
		return selected;
	}

}
