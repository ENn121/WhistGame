package exception;

/**
 * An exception thrown when the number of players doesn't meet the game logic
 */
@SuppressWarnings("serial")
public class NumberPlayersException extends Exception {
	public NumberPlayersException(String violation) {
		super(violation);
	}
}
